package com.editphoto;

public @interface FromXML {

}
